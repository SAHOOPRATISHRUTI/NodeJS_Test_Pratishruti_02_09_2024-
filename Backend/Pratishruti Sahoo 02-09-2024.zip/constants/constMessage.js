const duplicateEmail = "Duplicate Email Found"
const createdSucess = "Created Sucessfully"
const retrievalSuccess = "Retrive Data sucessfully"
const employeeNotFound ="employee not found"
const maximumAttempted ="maximum attempte reached"
const otpNotFound="OTP NOt Found"
const otpExpired="OTP EXpirde"
const inValidOtp="Invalid OTP"
module.exports={
    duplicateEmail,
    createdSucess,
    retrievalSuccess,employeeNotFound,maximumAttempted,otpExpired,otpNotFound,inValidOtp
}