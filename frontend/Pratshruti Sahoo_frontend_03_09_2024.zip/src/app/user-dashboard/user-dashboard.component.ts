import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceService } from '../services/service.service'; 
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  addEmployeeForm: FormGroup;
  employeeName: string|null='';

  constructor(
    private serviceService: ServiceService,
    private fb: FormBuilder,
    private router: Router,
    private toaster: ToastrService
  )  {
    this.addEmployeeForm = this.fb.group({
      employeeName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
      email: ['', [Validators.required, Validators.email]],
      employeeId: ['', Validators.required],
      designation: ['', Validators.required],
      department: ['', Validators.required],
      unit: ['', Validators.required]
    });

    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras.state) {
      this.employeeName = navigation.extras.state['employeeName'];
      console.log(this.employeeName);
    }
  }

  ngOnInit() {
    // if (typeof window !== 'undefined' && window.sessionStorage) {
    //   this.employeeName = sessionStorage.getItem('employeeName');
    // }
  }

  onSubmit() {
    if (this.addEmployeeForm.valid) {
      this.serviceService.createEmployee(this.addEmployeeForm.value).subscribe(
        response => {
          console.log('Employee added successfully:', response);
          this.toaster.success(response.message);
          this.addEmployeeForm.reset();
        },
        error => {
          console.error('Error adding employee:', error);
          this.toaster.error(error.error.message);
        }
      );
    }
  }
}
