import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  private apiUrl = "http://localhost:1200/api";

  constructor(private http: HttpClient) { }

  //requestOTP
  requestOTP(email: string): Observable<any> {
    const urlStr = `${this.apiUrl}/auth/request-otp`;
    return this.http.post(urlStr, { email }).pipe(
      catchError(this.handleError)
    );
  }

  verifyOtp(email: string, otp: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/auth/verify-otp`, { email, otp }).pipe(
      catchError(this.handleError)
    );
  }
  
  

  //createEmployee
  createEmployee(employeeData: any): Observable<any> {
    const urlStr = `${this.apiUrl}/employees`;
    return this.http.post(urlStr, employeeData).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: any) {
    console.error('An error occurred:', error);
    return throwError(error);
  }
}
